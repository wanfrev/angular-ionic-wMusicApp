export const API_BASE_URL = "http://localhost:4000/api"; // cambia a tu IP o dominio en producción
